kiks('robot_wars'); % Start up KiKS using robot_wars.tif as arena
kiks_kiksnet('knockknock'); % Start a KiKSnet server with the administrator password set to 'knockknock'
