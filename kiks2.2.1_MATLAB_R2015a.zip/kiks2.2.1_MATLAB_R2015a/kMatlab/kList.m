function kList(ref)
%KLIST   Display the list of commands of Khepera
%
%kList(ref)
%  Use the reference obtained with kopen.

% Written by Yves Piguet, 9/98.

kcmd(ref,'list',1)
