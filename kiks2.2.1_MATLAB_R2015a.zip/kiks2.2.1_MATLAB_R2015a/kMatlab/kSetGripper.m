function res=kSetGripper(ref,value);
res=kTurret(ref,1,sprintf('D,%d',value));