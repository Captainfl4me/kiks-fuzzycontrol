function res=kSetArm(ref,value);
res=kTurret(ref,1,sprintf('E,%d',value));