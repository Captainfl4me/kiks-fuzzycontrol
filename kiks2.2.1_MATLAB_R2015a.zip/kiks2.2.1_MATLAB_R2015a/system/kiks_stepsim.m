% -----------------------------------------------------
%  (c) 2000-2004 Theodor Storm <theodor@tstorm.se>
%  http://www.tstorm.se
% -----------------------------------------------------

function kiks_stepsim
global KIKS_SIM_STEP

KIKS_SIM_STEP=1;